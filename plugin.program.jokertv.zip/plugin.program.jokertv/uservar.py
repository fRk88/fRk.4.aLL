import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/Toofaces2/jokertvkodi/main/wizard.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/Toofaces2/jokertvkodi/blob/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
